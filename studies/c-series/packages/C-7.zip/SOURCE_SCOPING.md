# Source scoping

Context of use: _not stated_

Artifact: _not stated_

Source class: published document

The evidence boundary is drawn over PASSAGES, not pages: one page can
carry both excluded argument and admissible front matter.

## Admitted

- All 146 extracted passages of NTRS-20200002832, "Applying NASA-STD-7009 Standard for Models and Simulations to Surrogate and Other Statistical Models" (K.L. Johnson, NASA Engineering and Safety Center, Marshall Space Flight Center), the sole document admitted this session. This includes the title/byline front matter (P.1 P1), the abstract (P.1 P2-P3), the body argument, the worked "rough example" of a statistical model assessed against the Standard, and any tables, figures and reference list carried in the extracted text. Anchors are drawn over passages (page/paragraph ids as shown in the source panel), not over whole pages.

## Excluded

_None recorded._

_The encoder recorded that nothing was excluded._

## Rationale

Nothing in this document is excluded: every extracted passage is admissible evidence for this encoding. Two boundary notes rather than exclusions. (1) The document is a conference paper arguing for wider application of NASA-STD-7009A; it is not the configuration-managed M&S documentation of a flight model, so passages that state what a modeler *should* do are admitted as the author's recommendation and not as evidence that a given practice *was* performed. (2) The paper is written against NASA-STD-7009A, whereas this review is encoded under the NASA-STD-7009B pack; where the two vocabularies differ, that is recorded in the ambiguity log rather than resolved silently. No material outside this single PDF was consulted or admitted.
