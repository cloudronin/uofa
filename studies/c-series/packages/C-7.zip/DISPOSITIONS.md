# Dispositions

One row per expected factor, not per firing. Verdicts are Confirmed /
Overruled / Not Applicable and adjudicate the PACKAGE, not the source.

| expected factor | firing | verdict | rationale |
|---|---|---|---|
| Software quality assurance | _silent_ | Acknowledged (evidenced) |  |
| Numerical code verification | _silent_ | Acknowledged (evidenced) |  |
| Discretization error | _silent_ | Source-absent |  |
| Numerical solver error | _silent_ | Acknowledged (evidenced) |  |
| Use error | _silent_ | Source-absent |  |
| Model form | _silent_ | Declined-mapping |  |
| Model inputs | _silent_ | Acknowledged (evidenced) |  |
| Test samples | _silent_ | Declined-mapping |  |
| Test conditions | _silent_ | Declined-mapping |  |
| Equivalency of input parameters | _silent_ | Declined-mapping |  |
| Output comparison | _silent_ | Declined-mapping |  |
| Relevance of the quantities of interest | _silent_ | Declined-mapping |  |
| Relevance of the validation activities to the COU | _silent_ | Acknowledged (evidenced) |  |
| Data pedigree | _silent_ | Acknowledged (evidenced) |  |
| Development technical review | _silent_ | Declined-mapping |  |
| Development process and product management | _silent_ | Acknowledged (evidenced) |  |
| Results uncertainty | _silent_ | Acknowledged (evidenced) |  |
| Results robustness | _silent_ | Acknowledged (evidenced) |  |
| Use history | _silent_ | Acknowledged (evidenced) |  |
