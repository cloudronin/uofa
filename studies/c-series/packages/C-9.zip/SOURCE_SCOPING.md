# Source scoping

Context of use: _not stated_

Artifact: _not stated_

Source class: published document

The evidence boundary is drawn over PASSAGES, not pages: one page can
carry both excluded argument and admissible front matter.

## Admitted

- ADMITTED: the whole of NTRS-20200002832-Johnson-2020.pdf, "Practical Application of NASA-STD-7009A Credibility Assessment to a Simple Model" (Johnson, 2020), as ingested this session and parsed into 146 passages. It is the only evidence admitted; no other file, no prior knowledge of the standard, and no outside reference was used to fill any cell. Every one of the 146 passages is in scope, comprising the narrative body (pages 1-8), the credibility-assessment scale legend and score summary (p.9), the process and configuration-control notes (pages 10-12), the test-matrix, DOE, measurement and modelling sections (pages 15-18), the results and uncertainty discussion (pages 22-23), and the two flattened credibility-table passages at p.25 (¶4 and ¶5). Bibliographic front matter -- title, byline, NTRS identifier -- is admitted with the rest. Anchors in this encoding name passages, not pages, in the form "p.N para M"; all 19 anchors resolve to passages inside this admitted set. Two of those anchors point at p.25 ¶4 and p.25 ¶5, which are the paper's credibility tables rendered by the extractor as run-on prose with the cell geometry lost; they are admitted as text, and the consequences of the lost geometry are recorded in the ambiguity log rather than being repaired silently.

## Excluded

_None recorded._

_The encoder recorded that nothing was excluded._

## Rationale

EXCLUDED: nothing from within the admitted file. No passage of NTRS-20200002832-Johnson-2020.pdf was withheld from review, and no cell in this encoding cites an excluded passage.

Excluded from the evidence base, and named here so the boundary is auditable: (1) the text of NASA-STD-7009A and NASA-STD-7009B themselves. The paper is written against 7009A and its 8-factor vocabulary, while the pack selected for this review is 7009B with 19 factors; neither standard was admitted, so no 7009B factor was scored from the standard's own definitions where the paper is silent. Those factors are carried as "--" rather than as low scores. This is logged as a schema finding in the ambiguity log. (2) The "investigation final report" that p.10 para 5 says will carry the additional test-planning, performance, data-analysis and modelling detail. It is referenced by the paper but was not provided and is not in the admitted set, so anything it would have supported is unavailable here rather than assumed. (3) Any figure, table shading, cell colour or layout position that did not survive PDF text extraction. Where a value was legible only by position, it is recorded as recovered with its recovery method, per A-8, not read off directly. (4) The extractor's own unsupported prose. At Model inputs the extractor asserted that instrumentation was "calibrated"; a literal search of all 146 passages for "calibrat" returns no match, so that wording is excluded from the evidence carrying the row and is logged as extractor-supplied.
