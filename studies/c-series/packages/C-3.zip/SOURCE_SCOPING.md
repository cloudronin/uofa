# Source scoping

Context of use: _not stated_

Artifact: _not stated_

Source class: published document

The evidence boundary is drawn over PASSAGES, not pages: one page can
carry both excluded argument and admissible front matter.

## Admitted

- All 146 parsed passages of NTRS-20200002832-Johnson-2020.pdf ("Statistical Modeling Case Study: NASA-STD-7009A Compliance", Johnson, 2020), the sole file admitted this session. This includes the worked case-study narrative (P.6-P.25), the completed NASA-STD-7009A Appendix E questionnaire and its "THE FINAL CREDIBILITY ASSESSMENT" table (P.25 P3-P6), the star-glyph caption and scale listing (P.9 P3, P.10 P1), and the author's commentary/NOTES sections (P.24, P.26). Bibliographic front matter (title, byline, report number, reference list) is admitted. Every anchor recorded in this encoding names a passage inside this set.

## Excluded

_None recorded._

_The encoder recorded that nothing was excluded._

## Rationale

Nothing in the file is excluded as evidence: no passage was marked "Exclude this passage" and no anchor cites an excluded passage. Two classes of source content are, however, UNREADABLE rather than excluded, and nothing is encoded from them: (1) the green shading on the copy of 7009A Table 3 at P.6/P.7 that carries the PREDECLARED required credibility levels, and (2) the blue series and radial positions of the star glyph at P.9/P.10 that carry the same requirements graphically. Both are figures; this workstation renders text only, so shading and position are not legible to me. Under A-10 I decline to invent them rather than guess, and I have not recorded a recovery method for them. Also note that P.7 P1-P9 is heavily OCR-garbled 7009A Table 3 boilerplate; it is admitted but too corrupt to carry a value, and nothing is anchored there.
