# Protocol-check (Credenza's own, live)

Credenza evaluates Part A's checks against the working set while you
work. `uofa import --protocol-check` is the authority at A-11 and runs
against the written artifacts.

| step | state | what is owed |
|---|---|---|
| A-1 Scope the source and write the scoping note | pass |  |
| A-2 Choose the minting namespace | pass |  |
| A-3 Open the run log | pass |  |
| A-4 Extract | pass |  |
| A-5 Give the workbook a home for citations | pass |  |
| A-6 Review every cell against the source | pass |  |
| A-7 Confirm required and achieved levels separately | pass |  |
| A-8 Anchor non-textual values by their recovery method | pass |  |
| A-9 Keep the ambiguity log as you go | pass |  |
| A-10 Decline rather than invent | pass |  |
| A-11 Import without signing | pass |  |
| A-12 Run the rules and draft the dispositions | pass |  |
| A-13 Completion | pass |  |

## Required levels

6 of 6 recoverable required levels carry an affirmation or a correction.

13 disposed, methods recorded:

- Software quality assurance -- not-recoverable
- Numerical code verification -- source-absent
- Discretization error -- source-absent
- Numerical solver error -- source-absent
- Use error -- not-recoverable
- Model form -- not-recoverable
- Test samples -- not-recoverable
- Test conditions -- not-recoverable
- Equivalency of input parameters -- not-recoverable
- Output comparison -- not-recoverable
- Relevance of the quantities of interest -- not-recoverable
- Relevance of the validation activities to the COU -- not-recoverable
- Development technical review -- not-recoverable
