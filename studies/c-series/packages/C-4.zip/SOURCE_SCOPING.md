# Source scoping

Context of use: _not stated_

Artifact: _not stated_

Source class: published document

The evidence boundary is drawn over PASSAGES, not pages: one page can
carry both excluded argument and admissible front matter.

## Admitted

- Admitted: the whole of NTRS-20200002832, "Applying NASA-STD-7009 Standard for Models and Simulations to Surrogate and Other Statistical Models", K.L. Johnson, NASA Engineering and Safety Center (NESC), Marshall Space Flight Center, AL. All 146 extracted passages are admitted, comprising: the title block and byline (P.1 P1); the abstract (P.1 P2-P3); the Introduction and the argument for extending the Standard to statistical, surrogate and regression models (P.1-P.5); the discussion of how 7009A frames the credibility problem, tailoring, and terminology (P.4-P.10); and the worked illustrative compliance example -- a foreign-object-debris (FOD) tire-penetration Design-of-Experiments regression model assessed against the NASA-HDBK-7009A Worksheet 1 -- together with its Responses/Comments/Notes/References/Links columns (P.11 onward), plus any reference list and back matter.
- The worked example is the only credibility assessment the document contains, and it is the passage set from which factor levels are encoded. It is admitted with the author's own qualification carried forward: "all examples and recommendations listed in this paper are provisional to P/P tailoring" (P.4 P1).
- This is a single admitted source; no companion or supporting document was supplied or is relied on.

## Excluded

_None recorded._

_The encoder recorded that nothing was excluded._

## Rationale

Excluded: no passage of this document is excluded. The boundary is drawn over passages, and every passage in the admitted set above is available to be cited.

Three limits on the admitted set are recorded here rather than as exclusions, because they narrow what the admitted text can support rather than removing text from scope:

1. The document assesses against NASA-STD-7009A and the NASA-HDBK-7009A Worksheet 1. This encoding is required to use the NASA-STD-7009B pack (19 credibility factors). Passages therefore support 7009A-vintage factors directly; any 7009B factor with no 7009A counterpart cannot be read from this document and will be left unread rather than inferred.

2. The document states that "Not all requirements are listed in the Worksheet" and that, for the author's purposes, "requirements begin with [M&S 6]" (P.11 P3). Factors bearing on requirements before [M&S 6] are consequently not evidenced here.

3. The PDF text layer interleaves the multi-column worksheet tables on P.11-P.13, so some sentences arrive spliced across columns. Where a value cannot be attributed to a column with confidence, it is logged as an ambiguity and left unread rather than guessed.

Nothing outside this file -- including NASA-STD-7009A/B themselves and the referenced Worksheet spreadsheet -- is admitted, and no cell may be anchored to them.
