# Source scoping

Context of use: _not stated_

Artifact: _not stated_

Source class: published document

The evidence boundary is drawn over PASSAGES, not pages: one page can
carry both excluded argument and admissible front matter.

## Admitted

- ADMITTED — the whole of NTRS-20200002832, K.L. Johnson, "Applying NASA-STD-7009 Standard for Models and Simulations to Surrogate and Other Statistical Models" (NASA Engineering and Safety Center, Marshall Space Flight Center, 2020), as uploaded this session: 146 extracted paragraphs spanning P.1 through the end of the report. Admitted in full and by passage, this includes: (a) the title/byline front matter and abstract on P.1; (b) the introductory and argumentative sections making the case for applying NASA-STD-7009A to statistical, surrogate and regression models; (c) the discussion of the Programmatic/Project Technical Authority threshold and of 7009A's life-cycle worksheet (Table 22 / nasa-hdbk-7009a_-_worksheet.xlsx); (d) the worked "rough example" beginning around P.11 — the foreign-object-debris (FOD) tire-penetration Design-of-Experiments regression model, its M&S Planning, development, verification, validation, uncertainty and reporting worksheet responses; (e) the final credibility assessment table and its accompanying discussion around P.25; and (f) any reference list, figure and table captions carried in the report. All encoded values must be anchored to passages inside this admitted set.

## Excluded

_None recorded._

_The encoder recorded that nothing was excluded._

## Rationale

EXCLUDED — nothing inside the uploaded file is excluded; every passage of NTRS-20200002832 is admitted. What is excluded is everything outside it, and this matters here because the report repeatedly points beyond itself: NASA-STD-7009 / 7009A and NASA-HDBK-7009A themselves, including Table 22 and the companion Excel worksheet (nasa-hdbk-7009a_-_worksheet.xlsx); NASA-STD-7009B, the revision named by this review's pack, which the report never cites and which postdates it; the underlying FOD tire-penetration test report and its data as archived on NTRS; the revised probabilistic risk assessment model referred to in the near-miss narrative; and the commercial statistical software used for the regression. None of those documents were uploaded, none were read, and no encoded cell may be anchored to them. Where a value would depend on them, the correct act is to decline under A-10 and record the gap in AMBIGUITY_LOG.md rather than to import it from outside the admitted set.
