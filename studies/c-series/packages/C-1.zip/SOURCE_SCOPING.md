# Source scoping

Context of use: _not stated_

Artifact: _not stated_

Source class: published document

The evidence boundary is drawn over PASSAGES, not pages: one page can
carry both excluded argument and admissible front matter.

## Admitted

- ADMITTED — the whole of NTRS-20200002832-Johnson-2020.pdf (Johnson, "NASA-STD-7009 Credibility Assessment of a Tire Foreign Object Debris Penetration Model", NASA NTRS 20200002832), the single file admitted this session and the sole evidence for this encoding. It parses into 146 passages, pp.1-25, and all 146 are admitted: body text, figures/tables rendered as text, title and byline front matter, and the reference list. Every anchor used in this encoding names a passage inside this admitted set: p.9 par.1, p.10 par.2, p.12 par.4, p.15 par.3, p.16 par.4, p.16 par.5, p.17 par.3, p.18 par.3, p.19 par.5, p.19 par.9, p.21 par.3, p.25 par.3. No other document, no external NASA-STD-7009B text, and no prior knowledge of the standard was admitted as evidence; the NASA-STD-7009B assessment pack supplies only the 19 factor names and the level vocabulary, not evidence.

## Excluded

_None recorded._

_The encoder recorded that nothing was excluded._

## Rationale

EXCLUDED — nothing. No passage of NTRS-20200002832-Johnson-2020.pdf was excluded; the "Exclude this passage" control was never used and the ledger records zero exclusion acts. The admitted boundary is therefore the whole document, drawn over all 146 passages rather than over pages, and no cell in this encoding cites an excluded passage because the excluded set is empty. Two things sit outside the evidence boundary and are named here so the boundary is unambiguous rather than silent: (1) the text of NASA-STD-7009B itself, which is not in evidence — the pack was selected for its 19 factor names only; and (2) the per-factor REQUIRED credibility levels, which are not excluded but absent: the source states achieved ratings and never predeclares required ones. That absence is recorded as a declination under A-7/A-10 in AMBIGUITY_LOG.md entry 2, not as an exclusion, and all 17 numeric required levels are marked not-recoverable rather than inferred.
