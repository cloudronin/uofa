Credenza working set -- SIGNED
==============================

This package carries an issuer seal over its measurement view, and a
decision signature if a decision was asserted. SIGNING.txt states what
each one covers and how to check it; keys/ carries the public half of
each key that signed, so this package can be verified from its own
contents.

It carries the
artifacts Part A of the encoding protocol says an encoding ends holding,
under the protocol's own names:

  SOURCE_SCOPING.md   what was admitted and what was excluded (A-1)
  RUN_LOG.md          what produced it, named exactly (A-3)
  workbook.xlsx       the workbook `uofa import` consumes, on the
                      pack's own template, each sheet carrying a
                      Source Anchor column (A-5)
  workbook/           the same sheets as text, to read and to diff.
                      A mirror; the CLI does not read these.
  AMBIGUITY_LOG.md    what the source underdetermined (A-9)
  REVIEW_LEDGER.md    every act, who did it, and the prior value
  DISPOSITIONS.md     a row per expected factor, not per firing (A-12)
  PROTOCOL_CHECK.md   Credenza's live read of Part A against this set

Protocol version: 0.1
Taking it away is reversible. Come back and carry on any time.

STATE AT EXPORT: every gate Credenza checks was clear when this
was written, and the decision is SIGNED. SIGNING.txt states
what each signature covers and how to check it.
