# Source scoping

Context of use: _not stated_

Artifact: _not stated_

Source class: published document

The evidence boundary is drawn over PASSAGES, not pages: one page can
carry both excluded argument and admissible front matter.

## Admitted

- Whole of NTRS-20200002832, K.L. Johnson (NASA NESC/MSFC), "Applying NASA-STD-7009 Standard for Models and Simulations to Surrogate and Other Statistical Models" (2020), all pages P.1-P.12 as paginated by this viewer: title/byline and abstract (P.1), the argument for extending 7009A to statistical models (P.1-P.5), and the worked compliance example for the disguised multi-ply-tire puncture-resistance surrogate model, comprising PREDECLARATIONS (P.6), the reproduced copy of Table 3 from 7009A Appendix E carrying the predeclared minimum credibility levels as green shading (P.7), and the prose responses to the credibility factors and reporting requirements that follow (P.7 onward), together with references and back matter.

## Excluded

_None recorded._

_The encoder recorded that nothing was excluded._

## Rationale

Nothing is excluded. Every passage of NTRS-20200002832-Johnson-2020.pdf is admitted and available as an anchor; no passage has been marked "Exclude this passage" in the source pane. Three boundary notes belong with that, and one correction.

BOUNDARY NOTE 1 - standard version. The paper is written against NASA-STD-7009A and its worked example is scored on 7009A's eight credibility factors (Data Pedigree, Input Pedigree, Verification, Validation, Uncertainty Characterization, Results Robustness, M&S History, M&S Process/Product Management). The pack selected for this encoding, as the brief directed, is NASA-STD-7009B, whose Credibility Factors sheet carries 19 differently-named rows. Where this encoding uses 7009A factor names it is quoting the paper's own words, not the pack's. Ambiguity log entry 2 states the consequences in full.

BOUNDARY NOTE 2 - non-textual values. The predeclared minimum credibility levels on P.7 (Table 3) are carried by green cell shading, and the achieved levels on P.9 are carried by a radar chart whose text layer is only the legend. Neither is text. Under A-8 such a value may be recorded only as recovered, with the method stated; the source pane in this application serves a text layer and no image, so no recovery method was available to me that I could honestly say I performed. Under A-10 the levels are therefore declined rather than invented: every level-bearing row on the Credibility Factors sheet stands as "Requirement not recoverable". Ambiguity log entry 1 states this policy once for the whole sheet.

BOUNDARY NOTE 3 - extractor prose. Two rows carry evidence sentences supplied by the hosted extractor that the anchored passages do not support (Output comparison, "Project-approved waiver", against a source that says "No waivers were required"; Test conditions, "test conditions were controlled", against a source that controls temperature and humidity during tire stowage). The source governs. Ambiguity log entry 3 gives both in full.

CORRECTION TO THE ADMITTED FIELD. The Admitted field above describes the admitted span as "P.1-P.12". That is wrong and I could not fix it: this page exposes two controls that both answer to the name "Admitted", the scoping-note textarea and the "ADMITTED THIS SESSION" file list, and the application refuses to write to either, replying that the name is ambiguous while offering no way to disambiguate it. The Excluded field has no such collision, which is why the correction is recorded here. The true extent: the file's text layer holds 146 passages running from P.1 to at least P.25, and this encoding anchors rows at p.7, p.8, p.9, p.10, p.14, p.16, p.17, p.18, p.19 and p.22. The admitted set was always the whole file - only the first description of its extent was short. No passage was excluded on the strength of the wrong span and no row is anchored outside the file.
