# Run log

The extractor, the agent and any automation driver are named separately
and never inherited from a document describing a different run.

| field | value |
|---|---|
| Extractor model | openai-compatible/anthropic/claude-sonnet-5 via openrouter.ai |
| Agent model | claude-opus-5 |
| Automation driver | _not recorded_ |
| Backend | hosted |
| Prompt hash | 35033e4b585b7065dea9d11044632b4a49841adbb870726540d18b3e0368f57d |
| App build | 0.1.0+6b68fa57 |
| Pack version | _not recorded_ |
| Standard | _not recorded_ |
| model | openai-compatible/anthropic/claude-sonnet-5 via openrouter.ai |
| backend | hosted |
| site commit | 0a68553dded2a6873abb21aca42dd6d7b33e832e |
| repo head | 0.1.0+6b68fa57 |
| base_uri | https://credenza.review/ns/anon-43cc/session |
| Protocol version | 0.1 |
| Started | 2026-08-29T16:21:43+00:00 |
| Extraction returned | 56 cells against 19 expected factors |
