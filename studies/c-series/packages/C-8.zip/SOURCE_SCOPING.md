# Source scoping

Context of use: _not stated_

Artifact: _not stated_

Source class: published document

The evidence boundary is drawn over PASSAGES, not pages: one page can
carry both excluded argument and admissible front matter.

## Admitted

- Admitted in full: NTRS-20200002832-Johnson-2020.pdf — K. L. Johnson, NASA Engineering and Safety Center (MSFC), "Applying NASA-STD-7009 Standard for Models and Simulations to Surrogate and Other Statistical Models". This is the sole item of evidence. It was uploaded to this Space this session and extracted here into 146 addressable passages; every one of those passages is admitted, including the bibliographic front matter (title, byline, affiliation) and the reference list. Every anchor in this encoding cites a passage of this file and no other. Anchors actually used: p.6 ¶2; p.8 ¶3; p.10 ¶2; p.12 ¶5; p.14 ¶3; p.14 ¶5; p.16 ¶5; p.18 ¶3; p.18 ¶5; p.19 ¶9; p.25 ¶3; p.25 ¶4; p.25 ¶5; p.25 ¶6. The passages p.6 ¶1 and p.10 ¶1 are admitted and were read as evidence about where the predeclared levels live, but carry no level value themselves and so anchor nothing.

## Excluded

_None recorded._

_The encoder recorded that nothing was excluded._

## Rationale

No passage of the admitted file is excluded. Nothing was withheld from consideration and nothing outside the file was consulted; in particular the text of NASA-STD-7009A and of NASA-STD-7009B themselves was not available in this session, so the pack's own rubric wording is not evidence here and is not cited anywhere in this encoding.

Two things fall outside the admitted set as a matter of fact rather than choice, and are recorded here because they bear on what this review could establish. (1) The figures. The document's predeclared credibility requirements exist only as green shading on a copy of 7009A Table 3 at pp.6-7, and as the blue trace of the star glyph at p.9-10; the extraction is text-only and returns no image data for these, and the "Recover from this figure" affordance produced no figure content. Those marks are therefore unreadable in this session and no required level was recovered from them — see the per-row "requirement not recoverable" waivers, all of which cite this. (2) The scope of the vocabulary. The study was performed against NASA-STD-7009A, whose Appendix E rubric carries 8 credibility factors; the pack selected for this review is NASA-STD-7009B, which carries 19. Eleven of the 19 rows are 7009B/ASME-V&V-40-era factors that the 2020 study had no occasion to predeclare against. Their achieved levels are anchored to what the document does say; their required levels are absent from the source rather than overlooked in it.
