# Protocol-check (Credenza's own, live)

Credenza evaluates Part A's checks against the working set while you
work. `uofa import --protocol-check` is the authority at A-11 and runs
against the written artifacts.

| step | state | what is owed |
|---|---|---|
| A-1 Scope the source and write the scoping note | pass |  |
| A-2 Choose the minting namespace | pass |  |
| A-3 Open the run log | pass |  |
| A-4 Extract | pass |  |
| A-5 Give the workbook a home for citations | pass |  |
| A-6 Review every cell against the source | pass |  |
| A-7 Confirm required and achieved levels separately | pass |  |
| A-8 Anchor non-textual values by their recovery method | pass |  |
| A-9 Keep the ambiguity log as you go | pass |  |
| A-10 Decline rather than invent | pass |  |
| A-11 Import without signing | pass |  |
| A-12 Run the rules and draft the dispositions | pass |  |
| A-13 Completion | pass |  |

## Required levels

**No required level was judged.** Every one either left the denominator below or was never populated. Nothing here was weighed against an achieved level, and this package does not claim otherwise.

19 disposed, methods recorded:

- Software quality assurance -- not-recoverable
- Numerical code verification -- not-recoverable
- Discretization error -- not-recoverable
- Numerical solver error -- not-recoverable
- Use error -- not-recoverable
- Model form -- not-recoverable
- Model inputs -- not-recoverable
- Test samples -- not-recoverable
- Test conditions -- not-recoverable
- Equivalency of input parameters -- not-recoverable
- Output comparison -- not-recoverable
- Relevance of the quantities of interest -- not-recoverable
- Relevance of the validation activities to the COU -- not-recoverable
- Data pedigree -- not-recoverable
- Development technical review -- not-recoverable
- Development process and product management -- not-recoverable
- Results uncertainty -- not-recoverable
- Results robustness -- not-recoverable
- Use history -- not-recoverable
