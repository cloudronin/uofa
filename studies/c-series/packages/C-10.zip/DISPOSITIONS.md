# Dispositions

One row per expected factor, not per firing. Verdicts are Confirmed /
Overruled / Not Applicable and adjudicate the PACKAGE, not the source.

| expected factor | firing | verdict | rationale |
|---|---|---|---|
| Software quality assurance | _silent_ | Acknowledged (evidenced) |  |
| Numerical code verification | _silent_ | Acknowledged (evidenced) |  |
| Discretization error | _silent_ | Declined-mapping |  |
| Numerical solver error | _silent_ | Acknowledged (evidenced) |  |
| Use error | _silent_ | Acknowledged (evidenced) |  |
| Model form | _silent_ | Acknowledged (evidenced) |  |
| Model inputs | _silent_ | Acknowledged (evidenced) |  |
| Test samples | _silent_ | Acknowledged (evidenced) |  |
| Test conditions | _silent_ | Acknowledged (evidenced) |  |
| Equivalency of input parameters | _silent_ | Acknowledged (evidenced) |  |
| Output comparison | _silent_ | Acknowledged (evidenced) |  |
| Relevance of the quantities of interest | _silent_ | Acknowledged (evidenced) |  |
| Relevance of the validation activities to the COU | _silent_ | Acknowledged (evidenced) |  |
| Data pedigree | _silent_ | Acknowledged (evidenced) |  |
| Development technical review | _silent_ | Acknowledged (evidenced) |  |
| Development process and product management | _silent_ | Acknowledged (evidenced) |  |
| Results uncertainty | _silent_ | Acknowledged (evidenced) |  |
| Results robustness | _silent_ | Acknowledged (evidenced) |  |
| Use history | _silent_ | Acknowledged (evidenced) |  |
