# Source scoping

Context of use: _not stated_

Artifact: _not stated_

Source class: published document

The evidence boundary is drawn over PASSAGES, not pages: one page can
carry both excluded argument and admissible front matter.

## Admitted

- Admitted in full: NTRS-20200002832-Johnson-2020.pdf — K. L. Johnson, "Applying NASA-STD-7009 Standard for Models and Simulations to Surrogate and Other Statistical Models", NASA Engineering and Safety Center / Marshall Space Flight Center, 2020. Parsed into 146 passages, all of which are admitted and all of which were searchable for anchoring. This includes (a) the expository sections on NASA-STD-7009A itself (pp. 2-5), (b) the worked FOD-impact / aircraft-tire case study and its filled-in 7009A reporting worksheet (pp. 6-24), and (c) bibliographic front matter (title, byline, affiliation). All 19 anchors in this encoding cite passages from this file and no other. It is the sole item of evidence; nothing else was consulted, and no external standard text, prior encoding or reference work was read.

## Excluded

_None recorded._

_The encoder recorded that nothing was excluded._

## Rationale

Nothing is excluded. No passage of the admitted file was withheld from anchoring and no "Exclude this passage" act was recorded, so the excluded set is empty and no anchor in this encoding cites an excluded passage.

Two boundary decisions are recorded here rather than as exclusions, because they limit what the admitted text can be read to support rather than removing it from the corpus:

1. The expository passages on pp. 2-5 quote NASA-STD-7009A's own purpose and scope statements. They are admitted, but they describe the Standard, not the model under review, and were not used to anchor any credibility factor. The one place such a passage was surfaced while searching for predeclared required levels (p.3 paragraph 5, p.3 paragraph 6) it was read only as evidence that the study sets acceptance criteria at programme/project level and declares no per-factor thresholds.

2. The source document is itself a secondary account: it reproduces a completed 7009A credibility assessment of the FOD-impact regression model. This encoding therefore encodes what the paper reports about that model, not an independent assessment of the model. No claim in this package rests on evidence outside the admitted file.
