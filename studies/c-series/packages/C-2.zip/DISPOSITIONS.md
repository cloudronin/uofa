# Dispositions

One row per expected factor, not per firing. Verdicts are Confirmed /
Overruled / Not Applicable and adjudicate the PACKAGE, not the source.

| expected factor | firing | verdict | rationale |
|---|---|---|---|
| Software quality assurance | _silent_ | Acknowledged (evidenced) |  |
| Numerical code verification | _silent_ | Acknowledged (evidenced) |  |
| Discretization error | _silent_ | Acknowledged (evidenced) |  |
| Numerical solver error | _silent_ | Acknowledged (evidenced) |  |
| Use error | _silent_ | Acknowledged (evidenced) |  |
| Model form | _silent_ | Acknowledged (evidenced) |  |
| Model inputs | _silent_ | Acknowledged (evidenced) |  |
| Test samples | _silent_ | Acknowledged (evidenced) |  |
| Test conditions | _silent_ | Acknowledged (evidenced) |  |
| Equivalency of input parameters | _silent_ | Acknowledged (evidenced) |  |
| Output comparison | _silent_ | Acknowledged (evidenced) |  |
| Relevance of the quantities of interest | _silent_ | Declined-mapping |  |
| Relevance of the validation activities to the COU | _silent_ | Declined-mapping |  |
| Data pedigree | _silent_ | Declined-mapping |  |
| Development technical review | _silent_ | Declined-mapping |  |
| Development process and product management | _silent_ | Declined-mapping |  |
| Results uncertainty | _silent_ | Declined-mapping |  |
| Results robustness | _silent_ | Declined-mapping |  |
| Use history | _silent_ | Declined-mapping |  |
