# Source scoping

Context of use: _not stated_

Artifact: _not stated_

Source class: published document

The evidence boundary is drawn over PASSAGES, not pages: one page can
carry both excluded argument and admissible front matter.

## Admitted

- Entire text of NTRS-20200002832, K.L. Johnson (NASA NESC/MSFC), "Applying NASA-STD-7009 Standard for Models and Simulations to Surrogate and Other Statistical Models" (2020), as uploaded this session: all pages, from the title/byline and abstract on p.1 through the closing sections and reference list. Admitted passages include the running argument (INTRODUCTION; THE PROBLEM 7009A ADDRESSES; WHAT IF 7009A ISN'T REQUIRED; the discussion of applying 7009A to statistical/surrogate models) and the worked "rough example showing compliance for a statistical model", including any tables, figures and captions carrying credibility-assessment levels. Bibliographic front matter (title, byline, affiliation) and the reference list are admitted as citable passages.

## Excluded

_None recorded._

_The encoder recorded that nothing was excluded._

## Rationale

Nothing in the uploaded document is excluded: the whole paper is admitted, so no passage of it is off-limits to citation. Excluded from the evidence base, and therefore not citable, is everything outside this single file: NASA-STD-7009A and NASA-STD-7009B themselves (referred to and quoted by the paper but not admitted here), Table 22 / the Excel life-cycle worksheet shipped with the Standard, and every work in the paper's reference list. Where this encoding needed a fact that lives only in those unadmitted sources, it is declined rather than inferred, and the declination is recorded in the ambiguity log.
