# Credibility report — COU1: Cardiopulmonary Bypass (CPB)

- **Assessed against:** ASME V&V 40
- **Risk tier:** 2
- **Extraction:** LLM extraction - meta-llama/Llama-3.3-70B-Instruct-Turbo via api.together.xyz
- **Device class:** Class II

## At a glance

| Completeness | Factors evidenced | Concerns | Gate checks |
|---|---|---|---|
| 85% | 11 of 13 | 2 High, 1 Moderate | 0 of 2 |

_85% of all factors evidenced; 2 factors required at Level 2 still need evidence; 2 high-severity concerns open before this is review-ready._

## Credibility factors

| Factor | Status |
|---|---|
| Output comparison | Not stated |
| Relevance of the validation activities to the COU | Not stated |
| Discretization error | Evidenced |
| Equivalency of input parameters | Evidenced |
| Model form | Evidenced |
| Model inputs | Evidenced |
| Numerical code verification | Evidenced |
| Numerical solver error | Evidenced |
| Relevance of the quantities of interest | Evidenced |
| Software quality assurance | Evidenced |
| Test conditions | Evidenced |
| Test samples | Evidenced |
| Use error | Evidenced |

## [1] Documentation completeness — concerns found

- **High concern (seen 3×).** Validation result has no comparedAgainst link — comparator data source is absent. Relates to: Output comparison.
- **High concern.** Context of Use has neither an applicability constraint nor an operating envelope — the COU is declared but its boundary of validity is undocumented. Relates to: Relevance of the validation activities to the COU.

## Package-level concerns

_Whole-assessment findings; they belong to neither section alone._

- **Moderate concern.** UofA conforms to ProfileComplete but declares no SensitivityAnalysis — a Complete profile is structurally expected to document sensitivity analysis alongside uncertainty quantification.

## What is still missing

- Output comparison
- Relevance of the validation activities to the COU
